import java.util.Scanner;

class Main{
	public static void main(String[]args){
		Proses p = new Proses();
		
		p.input();
		p.pilihan();
		p.pembayaran();
		p.cetak();
		
		
	}
}